# instancio-js - Test Data Generator for TypeScript & JavaScript

instancio-js is a **TypeScript/JavaScript test data generator** that auto-populates objects, interfaces, and classes with random values for unit tests: no manual fixtures, no boilerplate.
Inspired by [Instancio](https://github.com/instancio/instancio) for Java.

## Why instancio-js?

Tired of writing manual test fixtures? instancio-js generates fully populated TypeScript objects directly from your existing interfaces and classes; no extra schema, no configuration.

|                             | instancio-js | faker.js | Manual fixtures |
| --------------------------- | ------------ | -------- | --------------- |
| Reads your TypeScript types | ✅           | ❌       | ❌              |
| Zero boilerplate            | ✅           | Partial  | ❌              |
| Nested objects              | ✅           | Manual   | Manual          |
| Arrays, Sets, Tuples, Enums | ✅           | Manual   | Manual          |
| Field-level customization   | ✅           | ❌       | ❌              |

## Key Features

- **Test Data Generation**: Generate objects based on interfaces/classes with random values, no manual setup.
- **Recursive Generation**: Supports generating nested objects and recursive structures automatically.
- **Field-level Customization**: Fix, supply, or ignore individual fields with `set()`, `supply()`, and `ignore()`.
- **Primitive Value Generators**: Default generators for strings, numbers, booleans, dates, and more, all customizable.
- **Collections**: Generate arrays, Sets, and Tuples out of the box.

Example :

```typescript
import { Instancio } from 'instancio-js';

interface User {
  name: string;
  age: number;
}

const user: User = Instancio.of<User>().generate();
console.log(user);
```

**Output Example**:

```
{
  "name": "BZHWSMLUIWIQ", // Random uppercase string
  "age": 58753 // Random number
}
// note: generation can be customized
```

## To come

- **Intersection** type handling
- **Utility** types handling (`Pick`, `Omit`...)
- **Special** type handling (`never`, `void`...)

## Installation / Setup

To install the library via npm:

```bash
npm install instancio-js ts-patch
npx ts-patch install
```

### Prerequisites

- Typescript 5.0 or newer
- [ts-patch](https://github.com/nonara/ts-patch)

### Setup tsconfig.json (TypeScript Compiler Plugin)

To enable automatic schema generation, add the transformer to your `tsconfig.json`:

```json
{
  "compilerOptions": {
    "plugins": [
      {
        "transform": "instancio-js/dist/transformer"
      }
    ]
  }
}
```

### Setup for Jest / nx (ts-jest)

If you're using Jest with `@swc/jest` or `babel-jest` (the default in nx monorepos), these "transpile-only" runners don't compile a full TypeScript `Program`, so the transformer won't run. To fix this, use **ts-jest** instead:

`jest.config.ts` (or `.cts`):

```js
module.exports = {
  transform: {
    '^.+\\.tsx?$': [
      'ts-jest',
      {
        tsconfig: `${__dirname}/tsconfig.jest.json`,
        astTransformers: {
          before: ['instancio-js/dist/jest-transformer'],
        },
      },
    ],
  },
};
```

> **nx users**: nx generates jest projects with `@swc/jest` by default. Replace that project's `transform` with the ts-jest block above. Pointing ts-jest at a tsconfig **path** also avoids static-analysis errors in the `@nx/jest` graph plugin.

#### Angular (and other ESM-only packages)

The transformer needs the full `Program`, so `isolatedModules` must be `false`. But with `isolatedModules: false` ts-jest type-checks the whole program, and Angular 16+ ships ESM-only packages whose `exports` map has no `require` condition. Under a CommonJS test config TypeScript then cannot statically resolve sub-path imports such as `@angular/core/testing` or `@angular/common/http`, and reports `TS2307: Cannot find module ...` (or `TS1479` with `node16`/`nodenext` resolution).

These are type-resolution diagnostics only. The transformer itself just needs to resolve **your own** types in `Instancio.of<T>()`; Angular modules are resolved at runtime by jest's `moduleNameMapper` (set up by `jest-preset-angular`), not by TypeScript. So the fix is to tell ts-jest to ignore those diagnostics, **without changing `module` / `moduleResolution`**:

```js
// jest.config.ts (per Angular lib) - options are forwarded to ts-jest by jest-preset-angular
module.exports = {
  preset: '../../jest.preset.js',
  transform: {
    '^.+\\.(ts|mjs|js|html)$': [
      'jest-preset-angular',
      {
        tsconfig: '<rootDir>/tsconfig.spec.json',
        stringifyContentPathRegex: '\\.(html|svg)$',
        isolatedModules: false,
        // 2307: cannot find module (node10) - 1479: ESM imported from CJS (node16/nodenext)
        // 151002: ts-jest "hybrid module kind" warning (node16/nodenext)
        diagnostics: { ignoreCodes: [2307, 1479, 151002] },
        astTransformers: { before: ['instancio-js/dist/jest-transformer'] },
      },
    ],
  },
};
```

`tsconfig.spec.json` only needs `isolatedModules: false` added; keep the nx-generated `module` / `moduleResolution` as they are:

```json
{
  "extends": "./tsconfig.json",
  "compilerOptions": {
    "module": "commonjs",
    "isolatedModules": false,
    "types": ["jest", "node"]
  }
}
```

> This approach is **Node-version independent**: it does not rely on `require(esm)` (Node 22+) and works with any `moduleResolution` the project already uses. The trade-off is that suppressing `TS2307`/`TS1479` also hides genuine "module not found" mistakes in test files; keep type-checking those imports in your editor and `build`. If you prefer zero diagnostics suppression, use the explicit-schema escape hatch below.

A complete runnable workspace (nx + Angular 22 + `jest-preset-angular`, run with `nx test`) lives in `instancio-js-examples/instancio-js-nx-angular`.

### Setup for Vite / Vitest (Angular, React, Vue)

Vite-based stacks compile TypeScript with esbuild or a framework compiler (e.g.
`@analogjs/vite-plugin-angular`), **not** with `tsc`. The `tsconfig` `plugins` transformer is a
`tsc`/`ts-patch`-only mechanism, so it never runs there: `Instancio.of<T>()` reaches the runtime with
no schema and falls back to primitive defaults (`No schema provided: falling back to default
generation`). This affects modern Angular projects that test with Vitest, as well as React and Vue on
Vitest.

instancio-js ships an official Vite plugin that closes this gap. You keep writing the exact same
zero-boilerplate API - `Instancio.of<T>().generate()` - the plugin resolves `T` against a real
TypeScript program and injects the schema before the framework compiler runs. No `ts-patch`, no
`tsconfig` `plugins` entry.

```typescript
// vitest.config.ts (or vite.config.ts)
import { defineConfig } from 'vitest/config';
import angular from '@analogjs/vite-plugin-angular';
import { instancio } from 'instancio-js/dist/vite';

export default defineConfig({
  // instancio() must run before the Angular compiler; it already declares enforce: 'pre'.
  plugins: [instancio({ tsconfig: './tsconfig.spec.json' }), angular()],
  test: {
    globals: true,
    environment: 'happy-dom',
  },
});
```

Remove any `plugins: [{ "transform": "instancio-js/dist/transformer" }]` block from your
`tsconfig.spec.json`: it does nothing under Vite and the plugin above replaces it.

For React or Vue, the setup is identical - list `instancio()` alongside your framework plugin, there
is nothing Angular-specific about it:

```typescript
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { instancio } from 'instancio-js/dist/vite';

export default defineConfig({
  plugins: [instancio(), react()],
  test: { environment: 'happy-dom' },
});
```

**Plugin options**

| Option     | Default                 | Description                                                                                                         |
| ---------- | ----------------------- | ------------------------------------------------------------------------------------------------------------------- |
| `tsconfig` | nearest `tsconfig.json` | Config used to build the type-checking program. Point it at your test tsconfig so it sees the same files and types. |
| `include`  | `/\.[cm]?tsx?$/`        | Which module ids the plugin rewrites.                                                                               |

Runnable workspaces live in `instancio-js-examples/instancio-js-angular-vitest` (minimal Vite +
Vitest + `@analogjs/vite-plugin-angular`) and `instancio-js-examples/instancio-js-nx-angular-vitest`
(full nx + Angular 22 + Vitest).

### Escape hatch: explicit schema (no transformer at all)

If you cannot use ts-jest (for instance you must stay on `@swc/jest`, esbuild, or a pure runtime with
no compilation step), describe the type explicitly with the `t` builder and pass the schema as an
argument. No transformer, no `ts-patch`, no `tsconfig` plugin required:

```typescript
import { Instancio, t, Infer } from 'instancio-js';

const UserSchema = t.object({
  name: t.string,
  age: t.number,
  active: t.boolean,
  tags: t.array(t.string),
  role: t.enum(['admin', 'user', 'guest'] as const),
});

// Optionally derive the TS type from the schema instead of declaring it twice:
type User = Infer<typeof UserSchema>;

const user: User = Instancio.of<User>(UserSchema).generate();
const users: User[] = Instancio.ofArray<User>(5, UserSchema).generateArray();
```

An explicit schema always takes precedence: even when the transformer is active, a schema you pass by
hand is used as-is and never overwritten. All `set()`, `supply()`, `ignore()` and
`withCustomGenerator()` methods work the same way.

The `t` builder exposes: `t.string`, `t.number`, `t.boolean`, `t.bigint`, `t.symbol`, `t.date`,
`t.any`, `t.unknown`, `t.null`, `t.undefined`, `t.literal(value)`, `t.enum(values)`,
`t.object({ ... })`, `t.array(schema)`, `t.tuple(...schemas)`, `t.union(...schemas)`.

### Examples

Here are few examples with basic projects showcasing how to install the library : https://github.com/DorianNaaji/instancio-js-examples

Repo contains examples:

**for testing libs:**

- vitest
- jest
- mocha
- tape

**for frameworks:**

- nx + Angular 22 (jest)
- Angular + Vitest (`@analogjs/vite-plugin-angular`)
- nx + Angular 22 + Vitest

**for build libs:**

- standard (ts-node)
- rollup
- babel

## API Methods

### `Instancio.of<T>()`

Generates an object of the specified type `T`.

```typescript
const user: User = Instancio.of<User>().generate();
```

### `Instancio.ofArray<T>(size: number)`

Generates an array of objects of the specified type `T`.

```typescript
const users: User[] = Instancio.ofArray<User>(5).generateArray();
```

### `Instancio.ofSet<T>(size: number)`

Generates a set of objects of the specified type `T`.

```typescript
const userSet: Set<User> = Instancio.ofSet<User>(5).generateSet();
```

### `.set(field, value)`

Fixes a specific field to the given value; all other fields are still randomly generated.

```typescript
const user: User = Instancio.of<User>().set('email', 'test@example.com').generate();
// user.email === 'test@example.com'
```

### `.supply(field, supplier)`

Uses a supplier function to generate the value for a specific field, called once per generated object.

```typescript
const user: User = Instancio.of<User>()
  .supply('age', () => Math.floor(Math.random() * 18) + 18)
  .generate();
// user.age is always between 18 and 35
```

### `.ignore(field)`

Excludes a field from generation; the property will be absent (`undefined`) in the generated object.

```typescript
const user: User = Instancio.of<User>().ignore('password').generate();
// user.password === undefined
```

These three methods are chainable and can be combined freely:

```typescript
const user: User = Instancio.of<User>()
  .set('name', 'Alice')
  .supply('age', () => 30)
  .ignore('password')
  .generate();
```

## Usage

### Generating a Typed Object

You can generate a random object of a specific type based on a TypeScript interface or class.
(see intro example)

### Generating a Typed Array with a custom generator

You can generate an array of random objects with a specified type.

```typescript
export class CustomUserGenerator extends InstancioPrimitiveGenerator {
  constructor() {
    const generators = DefaultPrimitiveGenerator.getDefaultGenerators();
    const names = ['Alice', 'Bob', 'Charlie', 'David', 'Eve'];
    generators.set(PrimitiveTypeEnum.String, () => names[Math.floor(Math.random() * names.length)]);
    generators.set(PrimitiveTypeEnum.Number, () => Math.floor(Math.random() * 100) + 1);
    super(generators);
  }
}

const users: User[] = Instancio.ofArray<User>(5).withCustomGenerator(new CustomUserGenerator()).generateArray();
console.log(users);
```

**Output Example**:

```typescript
[
  { name: 'Alice', age: 75 },
  { name: 'David', age: 4 },
  { name: 'Charlie', age: 69 },
  { name: 'Eve', age: 80 },
  { name: 'David', age: 49 },
];
```

### Combining field-level customization with a custom generator

`set()`, `supply()`, and `ignore()` can be combined with `withCustomGenerator()` for fine-grained control:

```typescript
const users: User[] = Instancio.ofArray<User>(5)
  .withCustomGenerator(new CustomUserGenerator())
  .set('role', 'admin')
  .supply('email', () => `user-${Date.now()}@example.com`)
  .ignore('password')
  .generateArray();
```

**Output Example**:

```json
[
  { "name": "Alice", "age": 75, "role": "admin", "email": "user-1234567890@example.com" },
  { "name": "Bob", "age": 42, "role": "admin", "email": "user-1234567891@example.com" }
]
```

### Generating a Typed Set

Similarly, you can generate a set of random objects.

```typescript
const userSet: Set<User> = Instancio.ofSet<User>(5).generateSet();
console.log(userSet);
```

**Output Example**:

```
// Set
{
  { name: 'MGXIEYRLKAPG', age: 42 },
  { name: 'STZGVJHLRMLT', age: 25 },
  { name: 'FRUDNPBKCKAI', age: 34 },
  { name: 'VYMKHQSLGFWN', age: 31 },
  { name: 'HLOJCEZGWYIR', age: 22 },
}

```

### Generating Nested objects

Instancio-JS also supports recursive object generation for nested structures.

```typescript
interface RoomMate {
  name: string;
  age: number;
  email: string;
}

interface User {
  name: string;
  age: number;
  email: string;
  phone: string;
  address: string;
  country: string;
  city: string;
  zip: string;
  roomMate: RoomMate;
}

const user: User = Instancio.of<User>().generate();
console.log(user);
```

**Output Example**:

```json lines
{
  "name": "WQXFBHTPGXYQ",
  "age": 947618,
  "email": "EWOOTQTZDJPB",
  "phone": "917381",
  "address": "OAGVHHSONYFV",
  "country": "ABQKJDNTOZOA",
  "city": "MDXEZQDFNZQB",
  "zip": "4698786543",
  "roomMate": {
    "name": "AMQZFGKZDHKX",
    "age": 871270,
    "email": "AMQZFGKZDHKX"
  }
}
```

### Primitive Value Generators

Instancio-JS provides default generators for primitive types. Below is a list of types and their corresponding generator behavior:

- **String**: Random uppercase string (12 characters).
- **Symbol**: Symbol generated from a random string.
- **Number**: Random integer (6 digits).
- **BigInt**: Random BigInt (12 digits).
- **Boolean**: Random boolean value (`true` or `false`).
- **Date**: Random date between January 1st, 2000, and today.
- **Any**: Behaves like default (string).
- **DEFAULT**: Behaves like a string by default.

These can be fully customized.

### Customizing Object Generation

You can easily modify the behavior of how objects are generated by providing custom generators.

```typescript
import { DefaultPrimitiveGenerator, Instancio, InstancioPrimitiveGenerator } from '../../src';
import { PrimitiveTypeEnum } from '../../src/primitive-type.enum';

const generated: FewStringsProps = Instancio.of<FewStringsProps>().withCustomGenerator(new CustomGenerator()).generate();

// This is how you create a custom generator. This really simple
// generator just "extends" the Default one and overrides the behavior
// for String.
// You can do the same for every other PrimitiveTypes, or as well
// provide your own map, not even relying on the default one.
// Each key must be a PrimitiveTypeEnum and the value the generation function.
export class CustomGenerator extends InstancioPrimitiveGenerator {
  constructor() {
    const generators = DefaultPrimitiveGenerator.getDefaultGenerators();
    generators.set(PrimitiveTypeEnum.String, () => 'MyCustomGeneration');
    super(generators);
  }
}

export interface FewStringsProps {
  s1: string;
  s2: string;
  n: number;
}
```

## Support

instancio-js is a free, MIT-licensed library built and maintained on my own time. If it saves you from writing test fixtures by hand, you can support it.

[![Sponsor on GitHub](https://img.shields.io/badge/Sponsor-DorianNaaji-EA4AAA?logo=githubsponsors&logoColor=white)](https://github.com/sponsors/DorianNaaji)
[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-support-FFDD00?logo=buymeacoffee&logoColor=black)](https://buymeacoffee.com/dorian.naaji)

## License

instancio-js is distributed under the MIT license.

---

This README outlines the core features, installation process, and usage examples for the library. Feel free to extend or modify it as needed.
